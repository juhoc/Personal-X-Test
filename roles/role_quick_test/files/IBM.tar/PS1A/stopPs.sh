#!/bin/bash

echo -e "stoping PS Server\nPS server stopped"

sleep 3

kill -9 $(pgrep -f "/IBM/PS1A")
