#!/bin/bash

echo -e "Starting PS Server\nPS server starting.\nTo determine operational status, check the log files.\n(The log files be found in the directory /IBM/PS2A)"
sleep 3
perl -MPOSIX -e '$0="/java_ster/java-1.8/bin/java -XX:MaxNewSize=256m -XX:SurvivorRatio=4 -Xmn128m -Xmx512m -classpath /IBM/PS2A/lib/concurrent.jar:/IBM/PS2A/lib/perimeter.jar:/IBM/PS2A/lib/log4j.jar com.sterlingcommerce.perimeter.external.server.Shell"; pause' &
